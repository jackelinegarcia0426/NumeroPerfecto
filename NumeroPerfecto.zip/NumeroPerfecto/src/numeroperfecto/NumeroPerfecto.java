/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numeroperfecto;

import java.util.Scanner;

/**
 *
 * @author estudiante307
 */
public class NumeroPerfecto {

    // Método para calcular la suma de los divisores de un número
    public static int sumaDivisores(int numero) {
        int suma = 0;
        for (int i = 1; i <= numero / 2; i++) {
            if (numero % i == 0) { // Si i es un divisor de numero
                suma += i;
            }
        }
        return suma;
    }

    // Método principal para determinar si un número es perfecto
    public static boolean esNumeroPerfecto(int numero) {
        return sumaDivisores(numero) == numero; // Verificar si la suma de los divisores es igual al número
    }

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Introduce un número: ");
            int numero = scanner.nextInt();
            
            if (esNumeroPerfecto(numero)) {
                System.out.println(numero + " es un número perfecto.");
            } else {
                System.out.println(numero + " no es un número perfecto.");
            }
        }
    }
    
}
